/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek;

public class TestGirdisi {
    public String anahtar;
    public String[] degerler;


    public TestGirdisi(String anahtar, String[] degerler) {
        this.anahtar = anahtar;
        this.degerler = degerler;
    }
}

