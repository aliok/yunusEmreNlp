/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek.tk.yapi;

import java.util.Collections;
import java.util.List;

import net.zemberek.yapi.HarfDizisi;
import net.zemberek.yapi.Heceleyici;

/**
 * User: ahmet
 * Date: Sep 22, 2006
 */
public class TurkmenceHeceleyici implements Heceleyici {

    public List<String> hecele(HarfDizisi dizi) {
        return Collections.emptyList();
    }
}
