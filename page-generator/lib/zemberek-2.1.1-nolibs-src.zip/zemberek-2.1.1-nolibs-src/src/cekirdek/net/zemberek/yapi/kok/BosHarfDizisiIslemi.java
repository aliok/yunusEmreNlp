/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek.yapi.kok;

import net.zemberek.yapi.HarfDizisi;

/**
 * Bos kok ozel durumlari icin yapilacak islemi temsil eder, kelime uzerinde hic bir degisiklik yapmaz.
 */
public class BosHarfDizisiIslemi implements HarfDizisiIslemi {

    public void uygula(HarfDizisi dizi) {
    }
}