/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

/*
 * Created on 16.Haz.2005
 *
 */
package net.zemberek.istatistik;

public interface IstatistikYazici {
    public void yaz(Istatistikler ist);
}
