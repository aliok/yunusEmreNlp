/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek.islemler;

/**
 * User: ahmet
 * Date: Jun 12, 2006
 */
public interface DenetlemeCebi {

    boolean kontrol(String str);

    void ekle(String s);

    void sil(String s);

}
