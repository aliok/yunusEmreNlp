/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

/*
 * Created on 12.Haz.2005
 *
 */
package net.zemberek.istatistik;

public class KelimeTipZinciri {

}
