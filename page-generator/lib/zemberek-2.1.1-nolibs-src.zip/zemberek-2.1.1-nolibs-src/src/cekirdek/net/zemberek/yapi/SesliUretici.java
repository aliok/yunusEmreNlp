/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek.yapi;

/**
 * User: ahmet
 * Date: Aug 27, 2006
 */
public interface SesliUretici {

}
