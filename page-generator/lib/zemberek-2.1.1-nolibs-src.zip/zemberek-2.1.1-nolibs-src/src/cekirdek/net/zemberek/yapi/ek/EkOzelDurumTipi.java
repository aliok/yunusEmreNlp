/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek.yapi.ek;

/**
 * User: ahmet
 * Date: Sep 16, 2006
 */
public interface EkOzelDurumTipi {

    String ad();
}
