/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

/*
 * Created on 14.Eki.2005
 *
 */
package net.zemberek.istatistik;

public interface KokIstatistikBilgisi {
    public int getKullanimFrekansi();
}
