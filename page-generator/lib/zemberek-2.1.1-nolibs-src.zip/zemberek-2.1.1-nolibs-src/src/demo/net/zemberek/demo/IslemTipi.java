/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

/**
 */
package net.zemberek.demo;

public enum IslemTipi {
    YAZI_DENETLE,
    YAZI_COZUMLE,
    HECELE,
    ASCII_TURKCE,
    TURKCE_ASCII,
    ONER
}
