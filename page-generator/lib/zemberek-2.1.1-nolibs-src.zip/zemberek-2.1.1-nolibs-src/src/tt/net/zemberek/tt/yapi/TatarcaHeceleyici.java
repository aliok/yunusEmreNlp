/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek.tt.yapi;

import java.util.Collections;
import java.util.List;

import net.zemberek.yapi.HarfDizisi;
import net.zemberek.yapi.Heceleyici;

/**
 * Created by IntelliJ IDEA.
 * User: ahmet
 * Date: Mar 19, 2007
 * Time: 10:10:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class TatarcaHeceleyici implements Heceleyici{
    public List<String> hecele(HarfDizisi dizi) {
        return Collections.emptyList();
    }
}
