/*
 * Lisans bilgisi icin lutfen proje ana dizinindeki zemberek2-lisans.txt dosyasini okuyunuz.
 */

package net.zemberek.tt.yapi.ek;

public class TatarcaEkAdlari {
    public static final String IS_KOK = "IS_KOK";
    public static final String IS_COGUL_LAR = "IS_COGUL_LAR";
    public static final String IS_UZAKLASMA_DAN = "IS_UZAKLASMA_DAN";
    public static final String IS_BULUNMA_DA = "IS_BULUNMA_DA";
    public static final String IS_YUKLEME_NE = "IS_YUKLEME_NE";
    public static final String IS_YAKLASMA_GA = "IS_YAKLASMA_GA";
    public static final String IS_IYELIK_BEN_EM = "IS_IYELIK_BEN_EM";
    public static final String IS_IYELIK_SEN_EN = "IS_IYELIK_SEN_EN";
    public static final String IS_IYELIK_O_SE = "IS_IYELIK_O_SE";

}
